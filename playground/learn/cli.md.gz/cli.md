# CLI Reference

## Transcription

`soundscript transcribe input.wav --out melody.ss --report analysis.json --preview preview.wav`

Imports a solo melody from WAV or FFmpeg-supported MP3/video and validates its
reconstruction. Options: `--tempo auto|20..300`, `--instrument <GM name|program>`,
`--ffmpeg <path>`. See [transcription usage, limits and confidence](transcription.md).

The SoundScript CLI (`SoundScript.Cli`, assembly name `soundscript`) compiles
scripts and text to MIDI, renders offline timbre audio, and renders `.ss`/`.ssw`
scripts directly to WAV. It requires the .NET 10 SDK and runs on Windows, macOS,
and Linux.

```bash
dotnet run --project src/SoundScript.Cli -- <verb> <arguments>
```

Print the version and exit:

```bash
dotnet run --project src/SoundScript.Cli -- --version
dotnet run --project src/SoundScript.Cli -- -v
```

## Verbs

| Verb | Purpose |
|------|---------|
| `run` | Compile a `.ss` script to MIDI |
| `compose` | Compose plain text to MIDI via the [PhonemeComposer](phoneme-composer.md) (V3.1) |
| `prosody` | Compose plain text to MIDI via the word-level [ProsodyComposer](word-prosody.md) (V5) |
| `render` | Offline timbre synthesis: MIDI + SoundCSS → WAV/OGG ([V4](whats-new-v4.md)) |
| `wave` | Direct wave synthesis: `.ss`/`.ssw` → WAV via [SoundScript.Wave](wave-grammar.md) ([V7](whats-new-v7.md)) |
| `visual` | Inspect a deterministic temporal visual program without rendering frames ([temporal visual](visual-temporal.md)) |
| `video` | Export a synchronized WebM clip through a downstream FFmpeg adapter ([temporal visual](visual-temporal.md)) |

## `run` — compile a script

```bash
soundscript run <script.ss> [output.mid]
```

```bash
dotnet run --project src/SoundScript.Cli -- run examples/full-v2-showcase.ss
dotnet run --project src/SoundScript.Cli -- run examples/vocal-song.ss vocal-song.mid
```

- Resolves imports via `ProgramLoader`, interprets tracks and voices, writes MIDI.
- `output.mid` defaults to `output.mid` in the current directory.
- Compiler warnings print to stderr; they are informational and non-blocking.

## Runtime parameter snapshots (candidate API)

On the current feature branch, `run`, `wave`, and `inspect` accept opt-in
runtime values. This capability is a V16 candidate under validation and does
not change an invocation that omits `--runtime` and `--param`.

```bash
soundscript inspect samples/RuntimeParameters/monitor.ss --runtime --params \
  --param intensity=0.9 --param xpos=900 --at 2 --json
soundscript wave samples/RuntimeParameters/monitor.ss --runtime \
  --param intensity=0.9 --param xpos=900 --out critical.wav
soundscript run samples/RuntimeParameters/monitor.ss --runtime \
  --param intensity=0.9 --out critical.mid
```

`inspect --params` lists the declarations, decimal defaults, supported bounds,
and active values. Repeated `--param name=value` options override defaults
using invariant decimal notation. Unknown, duplicate, malformed, or out-of-range
assignments are usage/source errors. `wave` writes a complete ordinary WAV;
`run` writes MIDI through the current interpreter. `inspect --at` returns the
scene at an elapsed time. These are one-shot snapshots, not an interactive
session or streaming renderer.

Runtime files are parsed with the opt-in runtime dialect and do not resolve
imports. Use the ordinary commands and `CompileFile` workflow for static
import graphs. See the [runtime parameter guide](runtime-parameters.md) and
[self-contained monitor example](../samples/RuntimeParameters/README.md).

Output:

```console-output
Wrote 24 notes across 1 track(s) and 14 sung syllable(s) across 1 voice(s) to vocal-song.mid at 100 BPM.
```

## `visual` — inspect a temporal visual program

```bash
soundscript visual <script.ss|script.ssv> [--at <seconds>]...
```

`visual` compiles visual intervals and automation to a deterministic timeline;
it deliberately does not choose an FPS or encode a video. A source may also
contain a normal MIDI track, as in `examples/visual-temporal.ssv`; the CLI
inspects the visual rail while the Playground can audition that same audio
rail. Query one or more arbitrary moments to see the state a future renderer
would receive:

```bash
dotnet run --project src/SoundScript.Cli -- visual examples/visual-temporal.ssv \
  --at 0 --at 1.5 --at 4 --at 4.5 --at 5 --at 8.75
```

Use either `1.5` or `1.5s` after `--at`. See [visual-temporal.md](visual-temporal.md)
for source syntax and synchronization semantics.

## `video` — render a WebM clip

```bash
soundscript video <script.ss|script.ssv> --output <clip.webm> [--fps 24|30|60] [--width <even-pixels>] [--height <even-pixels>] [--ffmpeg <path>]
```

The default output size is 1280×720, matching the canonical visual scene
viewport used by the Playground. Use `--width` and `--height` when a smaller
CLI render is required.

`video` produces a real, decode-verified WebM containing a VP9 video stream and
Opus audio stream. It first builds an immutable export plan by evaluating the
authoritative `VisualTimeline.StateAt(t)` function at the requested output
rate, then projects those snapshots into the canonical 1280×720 Playground
scene profile. The same fitted deterministic SoundScript.Wave PCM rail is used
by the browser Playground and CLI. FFmpeg combines the generated images and
audio to the visual timeline duration.

```bash
dotnet run --project src/SoundScript.Cli -- video examples/visual-temporal.ssv \
  --output demo.webm --fps 30
```

FFmpeg is a required external encoder because .NET does not provide VP9 and
Opus WebM codecs. Install an FFmpeg build with `libvpx-vp9` and `libopus` on
`PATH`, set `SOUNDSCRIPT_FFMPEG`, or pass `--ffmpeg <path>`. The CLI explicitly
decodes both output streams after encoding and fails if either stream is absent
or unreadable.

On Windows, one supported installation is:

```powershell
winget install --id Gyan.FFmpeg.Shared --exact
```

FPS stays at the rendering boundary:

```text
Authoring: VisualState = StateAt(t)
Rendering: Frame[n] = StateAt(n / outputFPS)
```

## `compose` — text to melody (V3.1)

```bash
soundscript compose "<text>" [output.mid|output.wav] [--append <script.ss>] [--emit-ss <path.ss>] [--wave] [--stereo]
```

### Standalone

Composes the text into its own MIDI file at 96 BPM:

```bash
dotnet run --project src/SoundScript.Cli -- compose "Twinkle twinkle little star"
```

```console-output
Composed 7 syllable(s) into 24 note(s) to output.mid at 96 BPM.
```

### `--append` — add the composed track to a script

Compiles the script first (imports, tracks, voices — exactly like `run`),
then appends the composed `phonemes` track to the same MIDI file, using the
script's tempo:

```bash
dotnet run --project src/SoundScript.Cli -- compose "How I wonder what you are" out.mid --append examples/vocal-song.ss
```

```console-output
Composed 7 syllable(s) and appended the phoneme track to examples/vocal-song.ss: 41 note(s) across 2 track(s) to out.mid at 100 BPM.
```

The script itself is not modified — the composed track exists only in the
generated MIDI.

### `--emit-ss` — export the composed AST as `.ss` source (V6)

Writes the pre-interpretation AST that `compose` would otherwise feed
straight into the MIDI generator out as human-formatted `.ss` DSL source, in
addition to the `.mid` file (default behavior without the flag is
unchanged):

```bash
dotnet run --project src/SoundScript.Cli -- compose "Twinkle twinkle little star" --emit-ss twinkle.ss
dotnet run --project src/SoundScript.Cli -- run twinkle.ss twinkle-viass.mid
```

`twinkle-viass.mid` is byte-identical to what `compose "Twinkle twinkle
little star" twinkle.mid` (no flag) produces directly — tempo, pitches,
durations, and velocities all round-trip. Hand-edit `twinkle.ss` before the
`run` step to change exactly what you edited and nothing else.

`--emit-ss` and `--append` cannot be combined: `--append` never keeps a
single AST representing "existing script + composed track" (it merges the
composed track into an already-interpreted program), so there's no correct
program to print. Passing both flags together is a usage error.

See [whats-new-v6.md](whats-new-v6.md) for the full design rationale.

### Determinism

Identical text produces identical MIDI bytes on every platform:

```bash
dotnet run --project src/SoundScript.Cli -- compose "Twinkle twinkle little star" a.mid
dotnet run --project src/SoundScript.Cli -- compose "Twinkle twinkle little star" b.mid
sha256sum a.mid b.mid   # identical hashes
```

### `--wave` — compose directly to WAV (V7)

Skips the MIDI step and renders the composed AST through
[SoundScript.Wave](wave-grammar.md):

```bash
dotnet run --project src/SoundScript.Cli -- compose "Twinkle twinkle little star" twinkle.wav --wave
dotnet run --project src/SoundScript.Cli -- compose "Twinkle twinkle little star" twinkle.wav --wave --emit-ss twinkle.ss
```

```console-output
Composed 7 syllable(s) into 24 note(s) and rendered to twinkle.wav via SoundScript.Wave (no MIDI step) at 96 BPM.
```

| Flag | Purpose |
|------|---------|
| `--wave` | Render through SoundScript.Wave instead of writing MIDI |
| `--stereo` | Write stereo WAV (with `--wave` only) |

`--wave` cannot be combined with `--append`. It can be combined with
`--emit-ss` to export both `.ss` source and a `.wav` in one command.

## `prosody` — word-level text to melody (V5)

```bash
soundscript prosody "<text>" [output.mid|output.wav] [--append <script.ss>] [--emit-ss <path.ss>] [--wave] [--stereo]
```

Same shape as `compose`, but pitch is planned top-down (phrase → word →
syllable) by the [`ProsodyComposer`](word-prosody.md) instead of per phoneme
category — the melody follows spoken stress and sentence contour rather than
a fixed pitch per phoneme. `compose`/`PhonemeComposer` are unaffected;
`prosody` is a separate, independent verb.

### Standalone

```bash
dotnet run --project src/SoundScript.Cli -- prosody "Twinkle twinkle little star"
```

```console-output
Composed 7 syllable(s) into 24 note(s) to output.mid at 96 BPM.
```

### `--append` — add the composed track to a script

Same behavior as `compose --append`, but appends a `prosody` track instead of
a `phonemes` track:

```bash
dotnet run --project src/SoundScript.Cli -- prosody "How I wonder what you are" out.mid --append examples/vocal-song.ss
```

### `--emit-ss` — export the composed AST as `.ss` source (V6)

Identical in shape and guarantees to `compose --emit-ss` (see above), just
sourced from the `ProsodyComposer`'s AST instead:

```bash
dotnet run --project src/SoundScript.Cli -- prosody "Twinkle twinkle little star" --emit-ss twinkle-prosody.ss
dotnet run --project src/SoundScript.Cli -- run twinkle-prosody.ss twinkle-prosody-viass.mid
```

Also mutually exclusive with `--append`, for the same reason.

`--wave` and `--stereo` behave the same as on `compose` — see
[`compose --wave`](#--wave--compose-directly-to-wav-v7).

## `render` — MIDI to audio (V4)

```bash
soundscript render <file.mid> --css <style.ssc> [--out <output.wav|ogg>] [--text "<source text>"]
```

Offline, deterministic timbre synthesis using [SoundCSS](soundcss.md):

```bash
dotnet run --project src/SoundScript.Cli -- compose "Twinkle twinkle little star" twinkle.mid
dotnet run --project src/SoundScript.Cli -- render twinkle.mid \
  --css examples/default.ssc --out twinkle.wav \
  --text "Twinkle twinkle little star"
```

```console-output
Rendered twinkle.mid with examples/default.ssc to twinkle.wav.
```

| Flag | Required | Purpose |
|------|----------|---------|
| `--css` | yes | SoundCSS (`.ssc`) stylesheet path |
| `--out` | no | Output path (default: `output.wav` in cwd) |
| `--text` | no | Source text for phoneme → MIDI note alignment |

MIDI is never modified — the renderer **reads** note events and adds spectral
envelopes via the [timbre engine](timbre-engine.md).

## `wave` — script to WAV (V8)

```bash
soundscript wave <script.ss|script.ssw> [output.wav] [--stereo]
  [--vocal <stem.wav>] [--vocal-at=<beats>] [--vocal-gain=<0-1>]
  [--tts-dir <folder>]
  [--offline-tts [espeak|prosody]] [--offline-tts-dir <folder>] [--offline-tts-voice <id>] [--seed=<n>]
```

Renders a script directly through [SoundScript.Wave](wave-grammar.md) with no
MIDI step. V8 adds **vocal stem mixing** — your own recordings in the exported
WAV (see [whats-new-v8.md](whats-new-v8.md)).

```bash
dotnet run --project src/SoundScript.Cli -- wave examples/full-song-wave.ss jingle.wav
dotnet run --project src/SoundScript.Cli -- wave examples/wave-vocal-stem.ssw vocal.wav
dotnet run --project src/SoundScript.Cli -- wave song.ssw out.wav \
  --vocal my-recording.wav --vocal-gain=0.9
dotnet run --project src/SoundScript.Cli -- wave song.ssw out.wav --tts-dir vocal-stems/
dotnet run --project src/SoundScript.Cli -- wave song.ssw out.wav \
  --offline-tts prosody --offline-tts-dir vocal-stems/
```

| Flag / argument | Required | Purpose |
|-----------------|----------|---------|
| `script.ss\|script.ssw` | yes | Input script path |
| `output.wav` | no | Output path (default: `output.wav` in cwd) |
| `--stereo` | no | Write stereo WAV instead of mono |
| `--vocal` | no | Mix a full vocal stem WAV (path relative to cwd or absolute) |
| `--vocal-at` | no | Start beat for `--vocal` (default: `0`) |
| `--vocal-gain` | no | Linear gain for `--vocal` (default: `1.0`) |
| `--tts-dir` | no | Folder of pre-rendered WAVs mapped to each `speak` phrase (slug filenames) |
| `--offline-tts` | no | Generate slug-named stems with an offline engine, then mix (default engine: espeak if installed, else prosody) |
| `--offline-tts-dir` | no | Output folder for `--offline-tts` (default: `<script-dir>/vocal-stems`) |
| `--offline-tts-voice` | no | eSpeak voice id when using `--offline-tts` (default: `en`) |
| `--seed` | no | Prosody seed for synthetic stems (default: `7`) |

**Flag ordering:** place `[output.wav]` immediately after the script path, before
`--stereo`. `wave script.ss --stereo out.wav` ignores the custom path and uses
the default `output.wav`.

Unlike `run`, the wave verb does not invoke `VocalInterpreter` — it loads the
AST via `ProgramLoader` and renders through `WaveRenderer` only. Wave-only
directives (`effect`, `speak`, named `humanize`) are rejected by `run` with a
clear error; use `wave` (or the Playground's automatic wave routing) instead.

## `vocal` — offline stem generation (V8)

```bash
soundscript vocal generate "<text>" --out <file.wav> [--wordbank-dir <path>] [--engine wordbank|composite|espeak|prosody] [--locale <code>] [--voice <id>] [--seed=<n>]
soundscript vocal batch <script.ss|script.ssw> --out-dir <folder> [--wordbank-dir <path>] [--engine wordbank|composite|espeak|prosody] [--locale <code>] [--voice <id>] [--seed=<n>] [--skip-existing]
```

Generates slug-named WAV files for `speak` phrases without rendering the full
mix. Uses the **SoundScript.Vocal** library (same engines as `wave --offline-tts`).

```bash
# Default: composite (corpus human audio → espeak → G2P timbre → prosody per word)
dotnet run --project src/SoundScript.Cli -- vocal generate "Hello welcome" \
  --out vocal-stems/hello-welcome.wav --locale en

dotnet run --project src/SoundScript.Cli -- vocal batch song.ssw \
  --out-dir vocal-stems/ --engine composite --skip-existing
```

| Flag / argument | Required | Purpose |
|-----------------|----------|---------|
| `generate` / `batch` | yes | Subcommand |
| `"<text>"` or `script.ssw` | yes | Phrase or script containing `speak` nodes |
| `--out` / `--out-dir` | yes | Output WAV path or folder |
| `--wordbank-dir` | no | Load locale packs + corpus from a wordbank checkout (`WORDBANK_DIR` env also works) |
| `--engine` | no | `composite` (default), `wordbank`, `espeak`, or `prosody` |
| `--locale` | no | Wordbank locale for corpus lookup and G2P (default: active catalog locale) |
| `--voice` | no | eSpeak voice id (default: `en`) |
| `--seed` | no | Prosody seed (default: `7`) |
| `--skip-existing` | no | Batch only — skip files that already exist |

→ [phase8-wordbank-vocal.md](phase8-wordbank-vocal.md) for corpus audio, licenses, and examples.

## Exit codes

| Code | Meaning |
|------|---------|
| `0` | Command completed successfully (warnings are allowed) |
| `1` | Source compilation or validation error |
| `2` | Invalid CLI usage |
| `3` | Missing input or dependency/environment failure |
| `4` | Render/export failure, including cancellation |

## Related

- [text-to-melody.md](text-to-melody.md) — how `compose`/`prosody` work, including the `--emit-ss` detour (V6)
- [phoneme-composer.md](phoneme-composer.md) — module reference
- [word-prosody.md](word-prosody.md) — `ProsodyComposer` module reference (V5)
- [whats-new-v6.md](whats-new-v6.md) — `--emit-ss` design and guarantees (V6)
- [whats-new-v7.md](whats-new-v7.md) — SoundScript.Wave and the `wave` verb (V7)
- [whats-new-v8.md](whats-new-v8.md) — vocal stems and `vocal` CLI (V8)
- [wave-grammar.md](wave-grammar.md) — `.ssw` grammar reference (V7+)
- [soundcss.md](soundcss.md) — SoundCSS timbre language (V4)
- [timbre-engine.md](timbre-engine.md) — offline renderer (V4)
- [language-reference.md](language-reference.md) — script syntax for `run`
- [examples.md](examples.md) — example catalog
## Installation and automation

<!-- GENERATED:CLI_DISTRIBUTION_START -->
`SoundScript.Cli` 15.0.0 is not published on nuget.org.

No CLI GitHub Release is published for this public version. Build from a source checkout.
<!-- GENERATED:CLI_DISTRIBUTION_END -->

Source checkout and local packaging validation are described in the
[release checklist](releasing.md). The strict validate and inspect commands
provide stable automation behavior.

```sh
soundscript validate scene.ssv
soundscript validate scene.ssv --json
soundscript inspect scene.ssv --at 1.5
soundscript wave song.ss --out song.wav
soundscript video scene.ssv --out scene.webm --check
```

`--out` and `-o` are accepted wherever an output is supported. Existing
positional output forms continue to work. Unknown flags, missing values,
duplicate options, and conflicting positional/explicit output forms return
exit code 2. Commands never prompt interactively.

Stable exit codes are: 0 success (warnings are allowed), 1 source
compilation/validation failure, 2 invalid CLI usage, 3 missing input or
dependency/environment failure, and 4 render/export failure.

`validate` parses the complete import graph and runs the existing MIDI, Wave,
visual, and SoundCSS semantic paths without writing media. Diagnostics have
`severity`, `code`, `file`, `line`, `column`, and `message`, for example
`scene.ssv:18:12 warning SS2104: visual extends beyond audio duration`.
`inspect` reports tempo, duration, track/note/event counts, visual/audio
durations, synchronization points, supported outputs, and the duration basis.
Visual programs accept `--at <seconds>`.

JSON mode uses schema version 1 and writes only JSON to stdout. The following
historical 13.0.2 example illustrates the schema; the version reflects the running build:

<!-- HISTORICAL_CONTEXT_START -->

```json
{"schemaVersion":1,"soundScriptVersion":"13.0.2","success":true,"command":"validate","input":"scene.ssv","diagnostics":[],"metadata":{},"results":null}
```

<!-- HISTORICAL_CONTEXT_END -->

`video --check` preflights timing, dimensions, FPS, frame count, output path,
FFmpeg, and the `libvpx-vp9`, `libopus`, and WebM capabilities without making
frames or replacing the output. WebM export requires FFmpeg; select it with
`--ffmpeg` or `SOUNDSCRIPT_FFMPEG`. Export media is staged beside the target,
verified, and atomically replaced, so failed exports leave an existing target
untouched.

The .NET single-file release workflow publishes Windows x64, Linux x64, macOS
x64, and macOS arm64 artifacts. The equivalent local commands are:

```sh
dotnet publish src/SoundScript.Cli -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
dotnet publish src/SoundScript.Cli -c Release -r linux-x64 --self-contained true -p:PublishSingleFile=true
dotnet publish src/SoundScript.Cli -c Release -r osx-x64 --self-contained true -p:PublishSingleFile=true
dotnet publish src/SoundScript.Cli -c Release -r osx-arm64 --self-contained true -p:PublishSingleFile=true
```

## Performance and progress

Long-running commands keep their concise output by default. Add `--verbose` to
see stage transitions, elapsed time, configuration, and bounded progress lines
on stderr. This keeps stdout valid for pipelines, including `--json --verbose`.

```sh
soundscript video scene.ssv --out scene.webm --verbose
soundscript wave song.ssw --out song.wav --verbose
```

Video frame generation accepts `--jobs N` (1–64). The default is a conservative
value capped at eight workers. Frames are still written with their canonical
numbered names, so single-worker and parallel renders remain byte-identical.
Press Ctrl+C during video rendering to cancel frame generation or FFmpeg; the
temporary directory is removed and the atomic final output is left untouched.

For historical context, a Windows/.NET 8 benchmark using `examples/visual-temporal.ssv` at 320×180,
30 FPS with real FFmpeg, the measured export changed from 14.92 s (serial
baseline) to 7.40 s with `--jobs 4`. The frame stage changed from roughly
11.88 s to 4.46 s, while the resulting WebM remained 326,999 bytes. These are
representative measurements rather than a runtime guarantee; codec and CPU
hardware affect the result.

## Public command coverage

The registration in CliArguments.Commands owns this inventory. All entries are public;
transcription modes can be experimental. No registrations are hidden or internal.

| Command | Visibility |
| --- | --- |
| `transcribe` | public |
| `run` | public |
| `compose` | public |
| `prosody` | public |
| `render` | public |
| `wave` | public |
| `visual` | public |
| `video` | public |
| `validate` | public |
| `inspect` | public |
| `vocal generate` | public |
| `vocal batch` | public |
| `wordbank ensure` | public |
| `wordbank normalize` | public |

Program.cs also handles `help`, `--help`/`-h` and `--version`/`-v`.
`--output`/`-o` alias `--out`; these are option aliases, not additional commands.

## Exit-code source mapping

Diagnostics.ExitCode owns exception values; Program.cs returns zero on success.

| Source condition | Exit code |
| --- | --- |
| `success` | `0` |
| `OperationCanceledException` | `4` |
| `CliUsageException` | `2` |
| `DependencyException or FileNotFoundException or DirectoryNotFoundException or UnauthorizedAccessException` | `3` |
| `ExportException` | `4` |
| `IOException` | `3` |
| `_` | `1` |
